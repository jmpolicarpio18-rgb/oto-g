<?php
require_once __DIR__ . '/../includes/config.php';

function clean_input($value) {
    return trim(filter_var($value ?? '', FILTER_SANITIZE_FULL_SPECIAL_CHARS));
}

$name = clean_input($_POST['name'] ?? '');
$phone = clean_input($_POST['phone'] ?? '');
$vehicle = clean_input($_POST['vehicle'] ?? '');
$preferredDate = clean_input($_POST['preferred_date'] ?? '');
$service = clean_input($_POST['service'] ?? '');
$branch = clean_input($_POST['branch'] ?? '');
$message = clean_input($_POST['message'] ?? '');
$sourcePage = clean_input($_POST['source_page'] ?? '');

if ($name === '' || $phone === '' || $vehicle === '' || $service === '' || $branch === '') {
    header('Location: ../booking.php?error=missing');
    exit;
}

$to = $business['email'];
$subject = 'New OtoGOAT Booking Request';
$body = "New booking request:\n\n" .
    "Name: {$name}\n" .
    "Phone: {$phone}\n" .
    "Vehicle: {$vehicle}\n" .
    "Preferred Date: {$preferredDate}\n" .
    "Service: {$service}\n" .
    "Branch: {$branch}\n" .
    "Message: {$message}\n" .
    "Source Page: {$sourcePage}\n";

$headers = 'From: no-reply@otogoat.ph' . "\r\n" .
           'Reply-To: no-reply@otogoat.ph' . "\r\n";

@mail($to, $subject, $body, $headers);

$csvPath = __DIR__ . '/../leads/booking-leads.csv';
$isNew = !file_exists($csvPath);
$fp = fopen($csvPath, 'a');
if ($fp) {
    if ($isNew) {
        fputcsv($fp, ['date_created', 'name', 'phone', 'vehicle', 'preferred_date', 'service', 'branch', 'message', 'source_page']);
    }
    fputcsv($fp, [date('Y-m-d H:i:s'), $name, $phone, $vehicle, $preferredDate, $service, $branch, $message, $sourcePage]);
    fclose($fp);
}

header('Location: ../thank-you.php');
exit;
