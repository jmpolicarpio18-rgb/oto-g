<?php
$business = [
    'name' => 'OtoGOAT',
    'tagline' => 'Zero To Greatest Of All Time',
    'email' => 'bookings@otogoat.ph',
    'phone_primary' => '0947 717 7778',
    'phone_secondary' => '0929 275 5188',
    'messenger_url' => 'https://m.me/otogoat',
    'facebook_url' => 'https://www.facebook.com/otogoat',
    'default_title' => 'OtoGOAT Auto Detailing Philippines | PPF, Graphene Coating & Ceramic Tint',
    'default_description' => 'Protect your ride with OtoGOAT. Premium paint protection film, graphene coating, nano ceramic tint, auto detailing, and car restoration services in the Philippines.',
];

$branches = [
    [
        'name' => 'New Manila / San Juan',
        'address' => '#1 Alicia St. corner Aurora Boulevard, San Juan',
        'phone' => '0947 717 7778',
    ],
    [
        'name' => 'Ortigas Extension / Pasig',
        'address' => 'Countryside Village, Brgy. Sta. Lucia, Pasig',
        'phone' => '0929 275 5188',
    ],
    [
        'name' => 'Novaliches / Quezon City',
        'address' => 'Novaliches, Quezon City',
        'phone' => '0947 717 7778',
    ],
    [
        'name' => 'Pampanga',
        'address' => 'Pampanga branch',
        'phone' => '0929 275 5188',
    ],
];

$services = [
    [
        'title' => 'Paint Protection Film',
        'short' => 'Invisible armor for paint against road debris, scratches, and daily driving damage.',
        'slug' => 'paint-protection-film',
    ],
    [
        'title' => 'Graphene / Ceramic Coating',
        'short' => 'Deep gloss, hydrophobic protection, easier cleaning, and long-lasting shine.',
        'slug' => 'graphene-ceramic-coating',
    ],
    [
        'title' => 'Nano Ceramic Tint',
        'short' => 'Heat rejection, UV protection, driving comfort, and premium privacy.',
        'slug' => 'nano-ceramic-tint',
    ],
    [
        'title' => 'Car Restoration',
        'short' => 'Paint correction and restoration for cars that need a clean comeback.',
        'slug' => 'car-restoration',
    ],
    [
        'title' => 'Auto Detailing',
        'short' => 'Interior and exterior detailing for a cleaner, sharper, better-looking ride.',
        'slug' => 'auto-detailing',
    ],
    [
        'title' => 'Motorcycle Protection',
        'short' => 'Premium coating and detailing for motorcycles, helmets, and daily riders.',
        'slug' => 'motorcycle-protection',
    ],
];
?>
