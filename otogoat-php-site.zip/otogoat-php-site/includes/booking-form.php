<form class="booking-form" action="actions/submit-booking.php" method="post">
    <input type="hidden" name="source_page" value="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
    <div class="form-row">
        <label>Full Name <input type="text" name="name" required placeholder="Juan Dela Cruz"></label>
        <label>Mobile Number <input type="tel" name="phone" required placeholder="09XX XXX XXXX"></label>
    </div>
    <div class="form-row">
        <label>Vehicle Model <input type="text" name="vehicle" required placeholder="Toyota Fortuner, Honda Civic, etc."></label>
        <label>Preferred Date <input type="date" name="preferred_date"></label>
    </div>
    <div class="form-row">
        <label>Service Needed
            <select name="service" required>
                <option value="">Choose a service</option>
                <option>Paint Protection Film</option>
                <option>Graphene / Ceramic Coating</option>
                <option>Nano Ceramic Tint</option>
                <option>Car Restoration</option>
                <option>Auto Detailing</option>
                <option>Motorcycle Protection</option>
                <option>Not sure yet / Need recommendation</option>
            </select>
        </label>
        <label>Preferred Branch
            <select name="branch" required>
                <option value="">Choose a branch</option>
                <option>New Manila / San Juan</option>
                <option>Ortigas Extension / Pasig</option>
                <option>Novaliches / Quezon City</option>
                <option>Pampanga</option>
                <option>Not sure yet</option>
            </select>
        </label>
    </div>
    <label>Message / Concern
        <textarea name="message" rows="4" placeholder="Tell us what you want done to your vehicle."></textarea>
    </label>
    <button class="btn btn-red" type="submit">Request My Quote</button>
</form>
