<?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar" aria-label="Main navigation">
    <a class="brand" href="index.php" aria-label="OtoGOAT home">
        <img src="assets/images/otogoat-logo-original.png" alt="OtoGOAT logo">
    </a>
    <button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false">
        <span></span><span></span><span></span>
    </button>
    <div class="nav-links">
        <a href="index.php" class="<?php echo $currentPage === 'index.php' ? 'active' : ''; ?>">Home</a>
        <a href="services.php" class="<?php echo $currentPage === 'services.php' ? 'active' : ''; ?>">Services</a>
        <a href="gallery.php" class="<?php echo $currentPage === 'gallery.php' ? 'active' : ''; ?>">Gallery</a>
        <a href="branches.php" class="<?php echo $currentPage === 'branches.php' ? 'active' : ''; ?>">Branches</a>
        <a href="about.php" class="<?php echo $currentPage === 'about.php' ? 'active' : ''; ?>">About</a>
        <a href="contact.php" class="<?php echo $currentPage === 'contact.php' ? 'active' : ''; ?>">Contact</a>
        <a class="btn btn-red nav-book" href="booking.php">Book Now</a>
    </div>
</nav>
