<?php
require_once __DIR__ . '/config.php';
$pageTitle = $pageTitle ?? $business['default_title'];
$pageDescription = $pageDescription ?? $business['default_description'];
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($pageDescription); ?>">
    <meta name="theme-color" content="#050505">
    <link rel="preload" href="assets/css/style.css" as="style">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
</head>
<body>
<?php include __DIR__ . '/loader.php'; ?>
<header class="site-header" id="top">
    <?php include __DIR__ . '/nav.php'; ?>
</header>
<main>
