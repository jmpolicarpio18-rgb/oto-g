<div id="site-loader" class="site-loader" role="status" aria-label="Loading OtoGOAT website">
    <div class="loader-inner">
        <div class="otogoat-loader" aria-hidden="true">
            <div class="loader-wordmark">
                <span class="loader-o loader-o-left">O</span>
                <span class="loader-red-t">
                    <span class="loader-t-vertical"></span>
                    <span class="loader-t-arrow"></span>
                </span>
                <span class="loader-small-o">o</span>
                <span class="loader-goat">
                    <span>G</span><span>O</span><span>A</span><span>T</span>
                </span>
            </div>
            <div class="loader-tagline">
                <span>ZERO</span><span>TO</span><span>GREATEST</span><span>OF</span><span>ALL</span><span>TIME</span>
            </div>
        </div>
        <div class="loader-progress"><span></span></div>
    </div>
</div>
