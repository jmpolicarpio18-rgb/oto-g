</main>
<footer class="site-footer">
    <div class="container footer-grid">
        <div>
            <img class="footer-logo" src="assets/images/otogoat-logo-original.png" alt="OtoGOAT logo">
            <p>Premium vehicle protection and auto detailing built for Philippine roads.</p>
        </div>
        <div>
            <h3>Services</h3>
            <a href="services.php#ppf">Paint Protection Film</a>
            <a href="services.php#coating">Graphene / Ceramic Coating</a>
            <a href="services.php#tint">Nano Ceramic Tint</a>
            <a href="services.php#restoration">Car Restoration</a>
        </div>
        <div>
            <h3>Contact</h3>
            <a href="tel:+639477177778"><?php echo htmlspecialchars($business['phone_primary']); ?></a>
            <a href="tel:+639292755188"><?php echo htmlspecialchars($business['phone_secondary']); ?></a>
            <a href="booking.php">Request a Quote</a>
        </div>
    </div>
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> OtoGOAT. All rights reserved.</p>
    </div>
</footer>

<div class="mobile-cta">
    <a href="tel:+639477177778">Call</a>
    <a href="<?php echo htmlspecialchars($business['messenger_url']); ?>" target="_blank" rel="noopener">Message</a>
    <a href="booking.php">Book</a>
</div>

<a class="floating-message" href="<?php echo htmlspecialchars($business['messenger_url']); ?>" target="_blank" rel="noopener" aria-label="Message OtoGOAT">Message</a>
<script src="assets/js/main.js"></script>
</body>
</html>
